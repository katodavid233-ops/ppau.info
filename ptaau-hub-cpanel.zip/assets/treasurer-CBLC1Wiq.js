const s="/assets/president-NTzmzJEW.jpeg",e="/assets/vice-president-UHqxi_ix.jpeg",t="/assets/secretary-cKKD5-s7.jpeg",r="/assets/treasurer-CX-g7plL.jpeg";export{s as p,t as s,r as t,e as v};
